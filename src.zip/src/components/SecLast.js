import React from "react";
import imgMan from '../assets/images/man-headset.svg'
import './SecLast.css'
function SecLast() {
  return (
    <div className="samMain">
    <div className="SecLastMain">
      <div className="imgMan">
        <img src={imgMan}  />
      </div>
      <div className="right">
        <div className="right-head">Sam Anderson</div>
        <div className="right-para">
          i could never have imagined that my ideas will have been actualised. I
          am so happy to be a guppy. Today, am also part of millions of viewers
          supporting guppies ideas. I dont hope for any incentive, but i feel
          happy when their ideas are fulfilled just like mine was actualised few
          years back. What will the world be like without Guppy.
        </div>
      </div>
    </div>
    </div>
  );
}
export default SecLast;
