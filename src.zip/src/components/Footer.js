import React from "react";
import "./Footer.css";
import fbImg from "../assets/images/eva_facebook-fill.svg";
import twitter from "../assets/images/twitter.svg";
import telegram from "../assets/images/telegram.svg";
import insta from "../assets/images/insta.svg";
import usaemoji from "../assets/images/US.svg";
import cemoji from "../assets/images/cLetter.svg";
function Footer() {
  return (
    <>
      <div className="footer-main">
        <div className="footer-left">
          <div className="foot-left-first">
            <div className="left-heading">Guppy</div>
            <div className="left-para">
              This is a new twist on crowdfunding meets social media. It is a
              site where entrepreneurs can come and pitch their business ideas.
              Not to the big venture capitalists, but to the everyday people who
              may want a piece of the action.
            </div>
            <div className="left-social-apps">
              <img src={fbImg} alt="fb" />
              <img src={twitter} alt="twitter" />
              <img src={telegram} alt="telegram" />
              <img src={insta} alt="insta" />
            </div>
          </div>
        </div>
        <div className="footerCenter">
          <div className="footcenter-prod-head">
            <div className="prod-foot">Products</div>
            <div className="prod-opt-one">Live sreaming</div>
            <div className="prod-opt-two">Crowdfunding</div>
            <div className="prod-opt-three">Donations</div>
          </div>
          <div className="foot-center-first">
            <div className="guppy-foot">Guppy</div>
            <div className="gup-opt-one">About</div>
            <div className="gup-opt-two">Terms of use</div>
            <div className="gup-opt-three">Privacy Policy</div>
            <div className="gup-opt-four">How it works?</div>
          </div>
          <div className="foot-center-second">
            <div className="support-foot">Support</div>
            <div className="sup-opt-one">FAQ</div>
            <div className="sup-opt-two">Self-Service</div>
          </div>
        </div>
        <div className="footer-right">
          <div className="foot-right-first">
            <div className="us-flag-emoji">
              <img src={usaemoji} alt="eng-opt" />
            </div>
            <div className="eng-opt">English</div>
          </div>
        </div>
      </div>
      {/* <hr/> */}
      <div className="copyRight">
        <div className="cr-text">
          Copyright <img src={cemoji} /> 2021 Guppy
        </div>
      </div>
    </>
  );
}
export default Footer;
