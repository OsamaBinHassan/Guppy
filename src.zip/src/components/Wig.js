import React from "react";
import imgLeft from "../assets/images/img-left.svg";
import imgRight from "../assets/images/img-right.svg";
import './Wig.css'
function Wig() {
  return (
    <div className="wig-main">
      <div className="wig-img-left">
        <img src={imgLeft} />
      </div>
      <div className="wig-center">
        <div className="wig-center-ques">Why Guppy?</div>
        <div className="wig-para-center">
          This is the real prospect recruiting tool tool. Using a 360o camera
          there will be a VR style tour of the facilities and vineyards where
          our product is grown and processed. As the tour group go through the
          facilities, a voice over will explain each portion for the facility
          and what it does to bring a quality product to the Ambassadors and
          prospects.
        </div>
      </div>
      <div className="wig-img-left">
        <img src={imgRight} />
      </div>
    </div>
  );
}
export default Wig;
