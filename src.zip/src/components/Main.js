import React from "react";
import "./Main.css";
import mainright from '../assets/images/mainright.svg';
function Main() {
  return (
    <div className="main-main">
      <div className="left-main">
        <div className="lef-main-one">
          Pitch your Business Ideas from the comfort of your home
        </div>
        <div className="left-main-two">
          Join our community of entrepreneurs to make the future better with
          your ideas
        </div>
        <button className="btn-left-main">Get Started</button>
      </div>
      <div className="right-main" >
        <img src={mainright} className="img-main"  width='100%' height='100%'/>
      </div>
      
    </div>
  );
}
export default Main;
