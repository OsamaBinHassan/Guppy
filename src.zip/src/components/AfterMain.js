import React from "react";
import  './AfterMain.css';
import svg1 from '../assets/images/svgThree.svg';
import svg2 from '../assets/images/svgOne.svg';
import svg3 from '../assets/images/svgTwo.svg';
function AfterMain() {
    return(
        
        <div className="AM-main">
            <div className="AM-fdiv">
                <div className="AM-fd-first">ACHIEVE MORE</div>
                <div className="AM-fd-Second">With Guppy, your ideas are one way to be realised</div>
            </div>
            <div className="AM-first">
                <div className="AM-first-One">
                    <div className="AM-First-Img"><img src={svg1}  /></div>
                    <div className="Svg1Text">Prepare your business ideas</div>
                </div>
                <div className="AM-First-Two">
                    <div className="AM-Second-Img"><img src={svg2} /></div>
                    <div className="Svg2Text">Pitch your business ideas</div>
                </div>
                <div className="AM-First-Three">
                    <div className="AM-Third-Img"><img src={svg3}  /></div>
                    <div className="Svg3Text">Viewers will fund your business ideas</div>
                </div>
            </div>
        </div>
        
    )
}
export default AfterMain;