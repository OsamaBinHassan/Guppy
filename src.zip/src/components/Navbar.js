import React from "react";
import "./Navbar.css";
function Navbar() {
  return (
    <div className="navbar">
    <div className="nav-main">
      <div className="nav-left">Guppy</div>
      <div className="nav-center">
        <div>About Us</div>
        <div>Services</div>
        <div>FAQ</div>
      </div>
      <div className="nav-right">
        <button>SignIn</button>
      </div>
    </div>
    </div>
  );
}
export default Navbar;
