import React from "react";
import img from "../assets/images/AMS-Right.svg";
import img2 from "../assets/images/Dollar-bucket.svg";
import "./AfterMainSec.css";
function AfterMainSec() {
  return (
    <div className="AMS-Main">
      <div className="AMS-Main-Left">
        <div className="AMS-left-img">
            <div>
          <img src={img2} />
          </div>
        </div>
        <div className="AMS-Text-First">Earn with our payout scheme</div>
        <div className="AMS-Text-Second">
          When you sign up as an guppy, you gain a chance of earning when you
          share our product tour link to prospects. Do not relent back .
        </div>
        <div className="AMS-btn">
          <button className="btn-left-main">Get Started</button>
        </div>
      </div>
      <div className="AMS-Main-Right">
        <div><img src={img} /></div>
      </div>
    </div>
  );
}
export default AfterMainSec;
