import React from "react";
import './Features.css';
function Features() {
  return (
    <div className="features-main">
      <div className="features-Heading">
        Key features we provide
      </div>
      <div className="key-Feat">
        <div className="border-One">
      <div className="features-key-first">
        <div className="fkf-img">
          <img src="" alt="" />
        </div>
        <div className="fkf-text">Quality pitching facility</div>
        <div className="fkf-para">
          Guppies can see their pitching tool at a click. No stress in pitching
          and getting ideas related to your pitch
        </div>
      </div>
      </div>
      <div className="border-Two">
      <div className="features-key-second">
        <div className="fks-img">
          <img src="" alt="" />
        </div>
        <div className="fks-text">Fast earning portal</div>
        <div className="fks-para">
          Our products are unique and result oriented. It is specially made for
          you to enjoy the beauty of nature. With our products facilities, we
          create the best out of nature.
        </div>
      </div>
      </div>
      <div className="border-Three">
      <div className="features-key-third">
        <div className="fkt-img">
          <img src="" alt="" />
        </div>
        <div className="fkt-text">Quality video tool for guppies</div>
        <div className="fkt-para">
          Our products are unique and result oriented. It is specially made for
          you to enjoy the beauty of nature. With our products facilities, we
          create the best out of nature.
        </div>
      </div>
      </div>
      </div>
    </div>
  );
}
export default Features;
