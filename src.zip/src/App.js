import AfterMain from "./components/AfterMain";
import AfterMainSec from "./components/AfterMainSec";
import Features from "./components/Features";
import Footer from "./components/Footer";
import Main from "./components/Main";
import Navbar from "./components/Navbar";
import SecLast from "./components/SecLast";
import Wig from "./components/Wig";


function App() {
  return (
    <>
      <Navbar />
      <Main />
      <AfterMain/>
      <AfterMainSec/>
      <Wig/>
      <Features/>
      <SecLast/>
      <Footer/>
      </>
  );
}

export default App;
